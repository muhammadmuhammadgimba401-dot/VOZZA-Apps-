# VOZZA Complete Interactive Demo (frontend)

This updated demo keeps the visual direction from the supplied screenshot: dark brown background, orange/gold accents, VOZZA header, mobile bottom navigation, and Home/Reels/Create/Shop/Alerts/Me. Media areas are larger for a social-feed feel, with image previews when you select local image files.

## Included screens/features
- Home feed, stories, hashtags, sample voice/photo posts, like buttons, comments/share/gift actions
- Reels screen and product discovery actions
- Create forms for voice, video/Reels, photos, stories, and text
- Local image preview after choosing a file (preview only; not uploaded)
- Shop, larger product cards, product detail, price + delivery display
- Add-to-cart, cart total, demo checkout form, demo order history
- Seller dashboard and create-product form
- Trust & Safety, price calculator, issue-report form
- Profile, messages, notifications, settings/privacy
- Wallet/creator gifts/commission preview
- Referral screen
- Responsive mobile layout and bottom navigation

## Open it
1. Download and unzip `VOZZA-Complete-Interactive-Demo.zip`.
2. Open `VOZZA_DEMO/index.html` in a browser, or upload the files to a GitHub repository and publish with GitHub Pages.

## Important honest limits
This is a frontend demo, not a live production app. Sample data and interactions only exist in the current page session and are cleared on refresh. Image previews use local browser object URLs and do not upload the files. There is no real account authentication, shared database, permanent media storage, live chat, verified sellers, real order processing, payments, refunds, creator payouts, or push notifications yet. Those require connecting a backend and service providers.

## Service preferences
This package does not use LocalStorage, Cloudflare D1, Cloudflare R2, Paystack, Firebase, or Supabase. Backend connections are not included; the code can be connected to the backend you choose.
